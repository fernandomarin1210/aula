import React from 'react';

function Footer(){
    return(
        <footer className="jumbotron text-center">
            <p>Footer</p>
        </footer>
    )
}

export default Footer;