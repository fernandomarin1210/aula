import React from 'react';

function About(){
    return(
        <div className = "row">
            <div className = "col-md-1"></div>
            <div className = "col-md-10">
                <h1>Sobre</h1>
                <p>Parágrafo de texto página teste</p>
            </div>
            <div className = "col-md-1"></div>
        </div>
    );
}

export default About;