import React from 'react';

function Home(){
    return(
        <div className = "row">
            <div className = "col-md-1"></div>
            <div className = "col-md-10">
                <h1>Home</h1>
                <p>Parágrafo de texto página teste</p>
            </div>
            <div className = "col-md-1"></div>
        </div>
    );
}

export default Home;